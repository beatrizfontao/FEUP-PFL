:- use_module(library(lists)).
:- use_module(library(random)).
:- use_module(library(system)).

:- consult('input.pl').
:- consult('logic.pl').
:- consult('menu.pl').
:- consult('bot.pl').

/*
  Displays the menu, builds the initial board and starts the game
*/
play :-
    menu(Size, GameMode),
    initial_state(Size, GameState),
    start(GameMode, GameState, player1).

/*
    display(+PlayerTurn, +GameState)
    Displays the turn of the current player and displays the board
*/
display(PlayerTurn, GameState) :-
    playernum(PlayerTurn, N),
    write('\33\[2J'), nl, write('Player '),  write(N), write(' turn'), nl, nl,
    display_game(GameState).

/*
  check_winner(+GameState, +Winner, +PlayerTurn, +GameMode)
  Checks if any of the players (1 or 2) won the game. If none won (e), the game continues
*/
check_winner(GameState, player1, _, _) :-
    display_game(GameState),
    nl, write('Player 1 Wins!'), !.
check_winner(GameState, player2, _, _) :-
    display_game(GameState),
    nl, write('Player 2 Wins!'), !.
check_winner(GameState, e, PlayerTurn, GameMode) :-
    turn(PlayerTurn, NewPlayerTurn),
    start(GameMode, GameState, NewPlayerTurn).

start(pvp, GameState, PlayerTurn) :-
    display(PlayerTurn, GameState),
    ask_for_move(GameState, PlayerTurn, Move, Valid),
    (Valid == false ->nl, write('Invalid Move!'), nl, start(pvp, GameState, PlayerTurn), !;
        move(GameState, Move, NewGameState),
        game_over(NewGameState, Winner),
        check_winner(NewGameState, Winner, PlayerTurn, pvp)
    ).

start(pvgreedyai, GameState, player1) :-
    display(player1, GameState), 
    ask_for_move(GameState, player1, Move, Valid),
    (Valid == false ->nl, write('Invalid Move!'), nl, start(pvgreedyai, GameState, player1), !;
        move(GameState, Move, NewGameState),
        game_over(NewGameState, Winner),
        check_winner(NewGameState, Winner, player1, pvgreedyai)
    ).

start(pvgreedyai, GameState, player2) :-
    sleep(1),
    display_game(player2, GameState), 
    choose_move(GameState, player2, 2, Move),
    move(GameState, Move, NewGameState),
    game_over(NewGameState, Winner),
    check_winner(NewGameState, Winner, player2, pvgreedyai).

start(greedyaivai, GameState, PlayerTurn) :-
    sleep(3),
    display(PlayerTurn, GameState), 
    choose_move(GameState, PlayerTurn, 2, Move),
    move(GameState, Move, NewGameState),
    game_over(NewGameState, Winner),
    check_winner(NewGameState, Winner, PlayerTurn, greedyaivai).


start(pvrandomai, GameState, player1) :-
    display_game(player1, GameState), 
    ask_for_move(GameState, player1, Move, Valid),
    (Valid == false ->nl, write('Invalid Move!'), nl, start(pvrandomai, GameState, player1), !;
        move(GameState, Move, NewGameState),
        game_over(NewGameState, Winner),
        check_winner(NewGameState, Winner, player1, pvrandomai)
    ).

start(pvrandomai, GameState, player2) :-
    sleep(1),
    playernum(player2, N),
    write('\33\[2J'), nl, write('Player '),  write(N), write(' turn'), nl, nl,
    choose_move(GameState, player2, 1, Move),
    move(GameState, Move, NewGameState),
    game_over(NewGameState, Winner),
    check_winner(NewGameState, Winner, player2, pvrandomai).


start(randomaivai, GameState, PlayerTurn) :-
    sleep(3),
    display_game(PlayerTurn, GameState),
    choose_move(GameState, PlayerTurn, 1, Move),
    move(GameState, Move, NewGameState),
    game_over(NewGameState, Winner),
    check_winner(NewGameState, Winner, PlayerTurn, randomaivai).
